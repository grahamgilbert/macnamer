#!/usr/bin/env python
'''
    saved.io Agent
    ----
    Server monitoring agent for Linux and Mac OS X
    
    Probably under the Apache 2 license, we'll see!
'''

import ConfigParser
from checks import checks
from daemon import Daemon
import sys
import os
import re
import sched
import time
import logging
import logging.handlers
import subprocess
path = os.path.realpath(__file__)
path = os.path.dirname(path)
config = ConfigParser.ConfigParser()
if os.path.exists('/etc/saved-agent/config.cfg'):
    configPath = '/etc/saved-agent/config.cfg'
else:
    configPath = path + '/config.cfg'
    
if os.access(configPath, os.R_OK) == False:
    print 'Unable to read the config file at ' + configPath
    print 'Agent will now quit'
    sys.exit(1)
        
config.read(configPath)
clientConfig = {}
clientConfig['logging'] = logging.INFO
clientConfig['checkFreq'] = 20

clientConfig['version'] = '0.0.1'
clientConfig['serverKey'] = config.get('Main', 'server_key')
    
# Tmp path
if os.path.exists('/var/log/saved-agent/'):
    clientConfig['tmpDirectory'] = '/var/log/saved-agent/'
else:
    clientConfig['tmpDirectory'] = '/tmp/' # default which may be overriden in the config later
    
if os.path.exists('/var/run/'):
    clientConfig['pidfileDirectory'] = '/var/run/'
else:
    clientConfig['pidfileDirectory'] = clientConfig['tmpDirectory']

if config.has_option('Main', 'logging_level'):
    customLogging = config.get('Main', 'logging_level')
    # Maps log levels from the configuration file to Python log levels
    loggingLevelMapping = {
        'debug'    : logging.DEBUG,
        'info'     : logging.INFO,
        'error'    : logging.ERROR,
        'warn'     : logging.WARN,
        'warning'  : logging.WARNING,
        'critical' : logging.CRITICAL,
        'fatal'    : logging.FATAL,
        }
    try:
        clientConfig['logging'] = loggingLevelMapping[customLogging.lower()]
    except KeyError, ex:
        clientConfig['logging'] = logging.INFO

class agent(Daemon):
    
    def run(self):
        
        # Get some basic system stats to post back for development/testing
        import platform
        systemStats = {'machine': platform.machine(), 'platform': sys.platform, 'processor': platform.processor(), 'pythonV': platform.python_version(), 'cpuCores': self.cpuCores()}
        
        if sys.platform == 'linux2':
            systemStats['nixV'] = platform.dist()
        
        elif sys.platform == 'darwin':
            systemStats['macV'] = platform.mac_ver()
        
        
        mainLogger.info('System: ' + str(systemStats))
                        
        mainLogger.debug('Creating checks instance')
        
        # Checks instance
        c = checks(clientConfig, mainLogger)
        c.doChecks(True, systemStats) #do the checks for the first time
        mainLogger.info('checkFreq: %s', clientConfig['checkFreq'])
        while True:
            time.sleep(clientConfig['checkFreq']) ##need something better than this - start a timer at the start so the total time is the checkFreq?
            c.doChecks(False, systemStats)
        
    
    def cpuCores(self):
        if sys.platform == 'linux2':
            grep = subprocess.Popen(['grep', 'model name', '/proc/cpuinfo'], stdout=subprocess.PIPE, close_fds=True)
            wc = subprocess.Popen(['wc', '-l'], stdin=grep.stdout, stdout=subprocess.PIPE, close_fds=True)
            output = wc.communicate()[0]
            return int(output)
        
        if sys.platform == 'darwin':
            output = subprocess.Popen(['sysctl', 'hw.ncpu'], stdout=subprocess.PIPE, close_fds=True).communicate()[0].split(': ')[1]
            return int(output)

if __name__ == '__main__':
    # Logging
    logFile = os.path.join(clientConfig['tmpDirectory'], 'saved-agent.log')
    
    if os.access(clientConfig['tmpDirectory'], os.W_OK) == False:
        print 'Unable to write the log file at ' + logFile
        print 'Agent will now quit'
        sys.exit(1)
        
    handler = logging.handlers.RotatingFileHandler(logFile, maxBytes=10485760, backupCount=5) # 10MB files
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    mainLogger = logging.getLogger('main')
    mainLogger.setLevel(clientConfig['logging'])    
    mainLogger.addHandler(handler)
    mainLogger.info('--')
    mainLogger.info('saved-agent started')
    mainLogger.info('--')
    mainLogger.info('serverKey: %s', clientConfig['serverKey'])
    
    argLen = len(sys.argv)
    ##set pidFile first, we can overwrite (debug later!)
    pidFile = os.path.join(clientConfig['pidfileDirectory'], 'saved-agent.pid')
    if argLen == 3 or argLen == 4: # needs to accept case when --clean is passed
        if sys.argv[2] == 'init':
            # This path added for newer Linux packages which run under
            # a separate sd-agent user account.
            if os.path.exists('/var/run/saved-agent/'):
                pidFile = '/var/run/saved-agent/saved-agent.pid'
            else:
                pidFile = '/var/run/saved-agent.pid'
    else:
        pidFile = os.path.join(clientConfig['pidfileDirectory'], 'saved-agent.pid')
    
    if os.access(clientConfig['pidfileDirectory'], os.W_OK) == False:
        print 'Unable to write the PID file at ' + pidFile
        print 'Agent will now quit'
        sys.exit(1)
    
    mainLogger.info('PID: %s', pidFile)
    if argLen == 4 and sys.argv[3] == '--clean':
        try:
            os.remove(pidFile)
        except OSError:
            # Did not find pid file
            pass
    daemon = agent(pidFile)
    
    if argLen == 2 or argLen == 3 or argLen == 4:
            if 'start' == sys.argv[1]:
                daemon.start()
            
            elif 'stop' == sys.argv[1]:
                daemon.stop()
            
            elif 'restart' == sys.argv[1]:
                daemon.restart()
            
            elif 'foreground' == sys.argv[1]:
                daemon.run()
            
            elif 'status' == sys.argv[1]:
                
                try:
                    pf = file(pidFile,'r')
                    pid = int(pf.read().strip())
                    pf.close()
                except IOError:
                    pid = None
                except SystemExit:
                    pid = None
                
                if pid:
                    print 'saved-agent is running as pid %s.' % pid
                else:
                    print 'saved-agent is not running.'
            elif 'update' == sys.argv[1]:
                ##check the server
                import json
                import urllib2
                try:
                    request = urllib2.urlopen('http://alpha.saved.io/update/')
                    response = request.read()
                
                except urllib2.HTTPError, e:
                    print 'Unable to get latest version info - HTTPError = ' + str(e)
                    sys.exit(1)
                    
                except urllib2.URLError, e:
                    print 'Unable to get latest version info - URLError = ' + str(e)
                    sys.exit(1)
                    
                ##load the json
                try:
                    theUpdate = json.loads(response)
                except Exception, e:
                    print 'something went wrong blud!'
                    sys.exit(1)
                ##if version numbers don't match
                if clientConfig['version'] != theUpdate['version']:
                    ##download the file
                    def downloadChunks(url):
                        """Helper to download large files
                            the only arg is a url
                           this file will go to a temp directory
                           the file will also be downloaded
                           in chunks and print out how much remains
                        """
                        from os import path as new_path
                        import math
                        baseFile = new_path.basename(url)

                        #move the file to a more uniq path
                        #umask(0002)
    
                        try:
                            temp_path='/tmp'
                            file = new_path.join(temp_path,baseFile)

                            req = urllib2.urlopen(url)
                            total_size = int(req.info().getheader('Content-Length').strip())
                            downloaded = 0
                            CHUNK = 256 * 10240
                            with open(file, 'wb') as fp:
                                while True:
                                    chunk = req.read(CHUNK)
                                    downloaded += len(chunk)
                                    print math.floor( (downloaded / total_size) * 100 )
                                    if not chunk: break
                                    fp.write(chunk)
                        except urllib2.HTTPError, e:
                            print "HTTP Error:",e.code , url
                            return False
                        except urllib2.URLError, e:
                            print "URL Error:",e.reason , url
                            return False

                        return file
                        ##download the latest tar.gz
                    the_file = downloadChunks(theUpdate['url'])
                
                    ##check the hash of the downloaded tar
                    import hashlib
                    def md5_for_file(filePath):
                        md5 = hashlib.md5()
                        file = open(filePath, 'rb')
                        while True:
                            data = file.read(8192)
                            if not data:
                                break
                            md5.update(data)

                        file.close()   
                        return md5.hexdigest()
                    the_md5 = md5_for_file(the_file)
                    if the_md5 != theUpdate['md5']:
                        ##checksums don't match, try one more time before bombing out
                        the_file = downloadChunks(theUpdate['url'])
                        the_md5 = md5_for_file(the_file)
                        if the_md5 != theUpdate['md5']:
                            sys.exit(1)
                    ##we're all good, extract the file
                    import tarfile
                    import zipfile
                    def extract_file(path, to_directory='.'):
                        if path.endswith('.zip'):
                            opener, mode = zipfile.ZipFile, 'r'
                        elif path.endswith('.tar.gz') or path.endswith('.tgz'):
                            opener, mode = tarfile.open, 'r:gz'
                        elif path.endswith('.tar.bz2') or path.endswith('.tbz'):
                            opener, mode = tarfile.open, 'r:bz2'
                        else: 
                            raise ValueError, "Could not extract `%s` as no appropriate extractor is found" % path
    
                        cwd = os.getcwd()
                        os.chdir(to_directory)
    
                        try:
                            file = opener(path, mode)
                            try: file.extractall()
                            finally: file.close()
                        finally:
                            os.chdir(cwd)
                    extract_file(the_file,'/tmp')
                    ##replace the files
                    import shutil
                    for name in theUpdate['files']:
                        ##copy each file to the current path
                        shutil.copy2('/tmp/saved-agent/'+name['name'], path)
                        ##delete the downloaded file
                
                    ##restart the agent
                    print 'updating would happen here'
                    daemon.restart()
                else:
                    print 'versions match, nothing to do'
