#!/usr/bin/env python
'''
    saved.io Checks
    ----
    Server monitoring agent for Linux and Mac OS X
    
    Probably under the Apache 2 license, we'll see!
    
    ToDo: Post the data to the server
'''
    
import os
import platform
import re
import subprocess
import sys
import urllib
import urllib2
class checks:
    def __init__(self, clientConfig, mainLogger):
        self.clientConfig = clientConfig
        self.mainLogger = mainLogger
        self.topIndex = 0
        self.os = None
        self.linuxProcFsLocation = None
        import socket
        socket.setdefaulttimeout(15)
    def getMemoryUse(self):
        if sys.platform == 'darwin':
            proc = subprocess.Popen(['top', '-l 1'], stdout=subprocess.PIPE, close_fds=True)
            top = proc.communicate()[0]
            
            try:
                proc.kill()
            except:
                self.mainLogger.debug('no killing today')
            proc = subprocess.Popen(['sysctl', 'vm.swapusage'], stdout=subprocess.PIPE, close_fds=True)
            sysctl = proc.communicate()[0]
            
            try:
                proc.kill()
            except:
                self.mainLogger.debug('still no killing')
            # Deal with top
            lines = top.split('\n')
            physParts = re.findall(r'([0-9]\d+)', lines[self.topIndex])
            # Deal with sysctl
            swapParts = re.findall(r'([0-9]+\.\d+)', sysctl)
            return {'physUsed' : physParts[3], 'physFree' : physParts[4], 'swapUsed' : swapParts[1], 'swapFree' : swapParts[2], 'cached' : 'NULL'}
        ##Linux
        if sys.platform == 'linux2':
            try:
                meminfoProc = open('/proc/meminfo', 'r')
                lines = meminfoProc.readlines()
            except IOError, e:
                ##bad times, couldn't read the file
                return False
            
            meminfoProc.close()
            regexp = re.compile(r'([0-9]+)')
            meminfo = {}
            for line in lines:
                values = line.split(':')
                try:
                    ##make a list with the meminfo value, and get the kb value
                    match = re.search(regexp, values[1])

                    if match != None:
                        meminfo[str(values[0])] = match.group(0)

                except IndexError:
                    break
            memData = {}
            memData['physFree'] = 0
            memData['physUsed'] = 0
            memData['cached'] = 0
            memData['swapFree'] = 0
            memData['swapUsed'] = 0
            
            # Phys
            physTotal = int(meminfo['MemTotal'])
            physFree = int(meminfo['MemFree'])
            physUsed = physTotal - physFree

            # Convert to MB
            memData['physFree'] = physFree / 1024
            memData['physUsed'] = physUsed / 1024
            memData['cached'] = int(meminfo['Cached']) / 1024
            
            # Swap
            swapTotal = int(meminfo['SwapTotal'])
            swapFree = int(meminfo['SwapFree'])
            swapUsed = swapTotal - swapFree

            # Convert to MB
            memData['swapFree'] = swapFree / 1024
            memData['swapUsed'] = swapUsed / 1024
            return memData
    
    def doChecks(self, firstRun, systemStats=False):
        macV = None
        self.linuxProcFsLocation = '/proc'
        if sys.platform == 'darwin':
            macV = platform.mac_ver()
        if not self.topIndex: # We cache the line index from which to read from top
            if macV and [int(v) for v in macV[0].split('.')] >= [10, 6, 0]:
                self.topIndex = 6
            else:
                self.topIndex = 5
        if not self.os:
            if macV:
                self.os = 'mac'
            else:
                self.os = 'linux'
        
        ##do the check(s)
        memory = self.getMemoryUse()
        
        checksData = {}
        checksData['os'] = self.os
        ##maybe put the version here? Doe we care what version they use if we're going to be doing auto updating somehow?
        checksData['serverKey'] = self.clientConfig['serverKey']
        
        ##make sure we managed to run the memory check
        if memory != False:
            checksData['memPhysUsed'] = memory['physUsed']
            checksData['memPhysFree'] = memory['physFree']
            checksData['memSwapUsed'] = memory['swapUsed']
            checksData['memSwapFree'] = memory['swapFree']
            checksData['memCached'] = memory['cached']
            
        # Include system stats on first time we run this
        if firstRun == True:
            checksData['systemStats'] = systemStats
            
        # Include server indentifiers
        import socket
        checksData['internalHostname'] = socket.gethostname()
        
        ##now we just need to send the data! but for now, we'll just dump it out
        self.mainLogger.info(checksData)
        encoded=urllib.urlencode(checksData)
        the_url='http://alpha.saved.io/checkin/'
        try:
            data = urllib.urlencode(checksData)
            req = urllib2.Request(the_url, data)
            req.add_header("Content-type", "application/x-www-form-urlencoded")
            response = urllib2.urlopen(req)
            the_page = response.read()
            #self.mainLogger.info(the_page)
            
            #req=urllib2.Request(the_url, encoded)
            #req.add_header("Content-type", "application/x-www-form-urlencoded")
            #response = urllib2.urlopen(req).read()
            #self.mainlogger.info(the_page)
            return True
        #except urllib2.URLError, e:
            #print e.code
            #print e.read()
        except urllib2.URLError as err: pass
        return False